# libsstv
Combining a few pieces of code into an extremely simple library for handling sstv in python
